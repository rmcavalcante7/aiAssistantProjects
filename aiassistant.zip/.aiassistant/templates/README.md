# Templates

This directory stores reusable starter files for common project artifacts.

Templates are useful when a project is being initialized and the structure is known, but the project-specific content has not been written yet.

---

# Purpose

Use templates to accelerate creation of:

- example context references
- decisions
- checklists
- feedback entries
- roadmap files
- specs
- prompts

---

# Rules

- templates are scaffolding, not source of truth
- generated files must be adapted to the real project
- do not keep template placeholders in finished files
- do not treat templates as active runtime context
- example files in this directory are illustrative only and must never be treated as `CURRENT_CONTEXT.md`

---

# Suggested usage

1. pick the closest template
2. copy it to the correct directory
3. adapt it to the real project
4. remove all placeholder text

---

END OF FILE
